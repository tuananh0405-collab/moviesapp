package com.example.mock;

import android.annotation.SuppressLint;

public interface OnFavChange {
    void OnFavChangeClick(int movieId);
}

